$(function () {
    $('.indexFooter button').click(function () {
        var uptime = $('#uptime').val();
        if (uptime != '') {
            var token = window.localStorage.getItem("token") !== undefined && window.localStorage.getItem("token") !== null ? window.localStorage.getItem("token") : '';
            $.ajax({
                type: 'post',
                url: '/api/resource/list?uptime=' + uptime,
                data: {token: token},
                dataType: 'json',
                beforeSend: function () {
                    $("#loading").show();
                },
                success: function (result) {
                    $("#loading").hide();
                    if (result.err == 0) {
                        if (result.info.end) {
                            $('.indexFooter').remove();
                            $('#uptime').val('');
                        } else {
                            $('#uptime').val(result.info.uptime);
                        }
                        var resourcelist = result.info.resourceList;
                        var scrollHeight = $('#mainBox').scrollTop();
                        $.each(resourcelist, function (k,v) {
                            var addimghtml = v.cover != '' ? '<div class="item_header" style="background-image: url(/' + v.cover + ');"></div>' : '';

                            var addhtml = '<a href="/resources/detail/' + v.id + '" title="' + v.title + '" target="_blank"> ' +
                                '<div class="resources_item el-col el-col-8"> ' +
                                '<div class="resources_itemBox"> ' + addimghtml +
                                '<div class="item_content"> ' +
                                '<div class="content_info"> ' +
                                '<div class="title">' + v.title + '</div> ' +
                                '<div class="author">' + v.author + '</div> ' +
                                '</div> </div> </div> </div> </a>';

                            $('#resourceList').append(addhtml);
                        });
                        $('#mainBox').scrollTop(scrollHeight);
                    }
                }
            })
        }
    });

    $('#downloadbtn').click(function () {
        var rid = $(this).data('rid');
        let userMsg = JSON.parse(window.localStorage.getItem('useMsg'));
        if(userMsg&&!userMsg.mobile){
            window.showPhoneBind();
            return false
        }
        if (window.localStorage.getItem("token") !== undefined && window.localStorage.getItem("token") !== '' && window.localStorage.getItem("token") !== null) {
            window.location.href = '/api/resource/download?token='+window.localStorage.getItem("token")+'&rid='+rid;
        } else {
            window.showTheloginBox();
        }
    });

    //下载码判断
    $('#downloadcodebtn').click(function () {
        var rid = $(this).attr('data-rid');
        var code = $('#downloadcode').val();
        if (code != '') {
            $.ajax({
                type: 'post',
                url: '/api/resource/downloadCode',
                data: {rid: rid, code: code},
                dataType: 'json',
                success: function (result) {
                    if (result.err == 0) {
                        window.location.href = '/api/resource/download?token='+window.localStorage.getItem("token")+'&rid='+rid+'&code='+code;
                    } else {
                        var warningMsg = {
                            isWarning:true,
                            showWaringBtn:false,
                            warningMsg:{
                            'image':'/global/static/image/warning.png',
                            'content':'<div>'+result.msg+'</div>',
                            }
                        }
                        window.showWarning(warningMsg);
                        //alert(result.msg);
                    }
                }
            })
        } else {
            var warningMsg = {
                isWarning:true,
                showWaringBtn:false,
                warningMsg:{
                'image':'/global/static/image/warning.png',
                'content':'<div>'+'下载码不能为空'+'</div>',
                }
            }
            window.showWarning(warningMsg);
            //alert('下载码不能为空');
        }
    });


    // 滚动事件触发
    var flag = true;
    $('#mainBox').bind('scroll', function(){
        if ($(this).scrollTop() + $(this).height() - 90 - $('.basefooter').height() + 150 > Math.round($('#resourceList').height())) {
            console.log('ok');
            console.log('下拉刷新了');
            //此处发起AJAX请求
            var uptime = $('#uptime').val();
            if (uptime != '' && flag) {
                flag = false;
                var token = window.localStorage.getItem("token") !== undefined && window.localStorage.getItem("token") !== null ? window.localStorage.getItem("token") : '';
                $.ajax({
                    type: 'post',
                    url: '/api/resource/list?uptime=' + uptime,
                    data: {token: token},
                    dataType: 'json',
                    beforeSend: function () {
                        $("#loading").show();
                    },
                    success: function (result) {
                        $("#loading").hide();
                        flag = true;
                        if (result.err == 0) {
                            if (result.info.end) {
                                $('.indexFooter').remove();
                                $('#uptime').val('');
                            } else {
                                $('#uptime').val(result.info.uptime);
                            }
                            var resourcelist = result.info.resourceList;
                            $.each(resourcelist, function (k,v) {
                                var addimghtml = v.cover != '' ? '<div class="item_header" style="background-image: url(/' + v.cover + ');"></div>' : '';

                                var addhtml = '<a href="/resources/detail/' + v.id + '" title="' + v.title + '" target="_blank"> ' +
                                    '<div class="resources_item el-col el-col-8"> ' +
                                    '<div class="resources_itemBox"> ' + addimghtml +
                                    '<div class="item_content"> ' +
                                    '<div class="content_info"> ' +
                                    '<div class="title">' + v.title + '</div> ' +
                                    '<div class="author">' + v.author + '</div> ' +
                                    '</div> </div> </div> </div> </a>';

                                $('#resourceList').append(addhtml);
                            });
                        }
                    }
                })
            }
        }
    });
});
