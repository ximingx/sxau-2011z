function closeLogin(){
    $('#loginBox').hide();
    $('#loginBoxModal').hide();
}
function showLogin(){
    $('#loginBox').show();
    $('#loginBoxModal').show();
}
window.initweixin = function(){
    var obj = new WxLogin({
        self_redirect:false,
        id:"login_container", 
        appid: "wxa108c96ace750dbf", 
        scope: "snsapi_login", 
        redirect_uri: "https%3a%2f%2finneed.club/?type=weixin",
        state: "",
        style: "",
        href: ""
    });
}
let BaseThis = this;    
new Vue({
    el: '#header_loginBox',
    data: function() {
        return {
            visible: false,
            isLogin:false,
            haveInfo:false,
            userMsg:[],
            countTime:''
        }
    },
    beforeMount(){
        let _this = this;
        this.checkMsg();
        this.countTime = setInterval(this.checkMsg, 10000);
        this.isLogin =  window.localStorage.getItem('isLogin')?window.localStorage.getItem('isLogin'):false;
        if(this.isLogin){
            _this.userMsg = JSON.parse(window.localStorage.getItem('useMsg'));
        }
        window.showTheloginBox = this.showTheloginBox;
        window.clearThehaveInfo = this.clearThehaveInfo;
        if(this.getUrlKey('code')){
            let _this = this;
            $.ajax({
                type: "GET",
                url: "/wxauth?code="+this.getUrlKey('code'),
                dataType: "json",
                success: function(data){
                    let userMsgInfo = data.info.userinfo;
                    userMsgInfo['token']= data.info.token;
                    let userMsgInfodata = {
                        isLogin:true,
                        userMsg:userMsgInfo
                    }
                    window.localStorage.setItem('isLogin', userMsgInfodata.isLogin);  
                    window.localStorage.setItem('token', userMsgInfo['token']);
                    window.localStorage.setItem('useMsg', JSON.stringify(userMsgInfodata.userMsg));
                    window.location.href = "/";
                }
            });
      }
    },
    beforeDestroy() {
        clearInterval(this.countTime);
    }
    ,methods:{
        getUrlKey: function (name) {
            return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.href) || [, ""])[1].replace(/\+/g, '%20')) || null
        },
        clearThehaveInfo(){
            this.haveInfo  = false;
        },
        showTheloginBox(){
            window.localStorage.removeItem('isLogin');
            window.localStorage.removeItem('useMsg');
            this.visible = false;
            let _this = this;
            $.ajax({
                url: "/exit",
                type: "GET",
                dataType: "json", //指定服务器返回的数据类型
                success: function (data) {
                   
                }
            });
            window.initweixin();
            $('#loginBox').show();
            $('#loginBoxModal').show();
        },
        checkMsg(){
            let postData ={
                token:this.userMsg.token?this.userMsg.token:'',
            };
            let _this = this;
            $.ajax({
                type: "POST",
                url: "/user/exist/msg",
                data: postData,
                dataType: "json",
                success: function(data){
                    if(data.err == 0){
                        _this.haveInfo = data.info;
                    }else{
                        _this.haveInfo  = false;
                    }
                }
            });
        },
        layout(){
            let postData ={
                token:this.userMsg.token?this.userMsg.token:'',
            };
            window.localStorage.removeItem('isLogin');
            window.localStorage.removeItem('useMsg');
            window.localStorage.removeItem("token");
            this.visible = !this.visible;
            let _this = this;
            $.ajax({
                url: "/exit",
                type: "POST",
                data: postData,
                dataType: "json", //指定服务器返回的数据类型
                success: function (data) {
                    window.location.href="/";
                }
            });
            // window.location.href="/";
        }
    }
})
new Vue({
    el: '#messageNotifyBox',
    data: function() {
        return {
            showMessageNotifyBox:false,
            istestUser:true,
            showMessageNotify:false,
            theMessageNotify:'',
            theContentQQ:'',
            userMsg:'',
            visible: false,
            info:'',
            infoPic:'/global/static/image/info.png',
            infofullPic:'/global/static/image/infofull.png',
            email:'',
            emailPic:'/global/static/image/emailfull.png',
            emailfullPic:'/global/static/image/email.png',
            share:'',
            sharePic:'/global/static/image/share.png',
            sharefullPic:'/global/static/image/sharefull.png',
            top:'',
            topPic:'/global/static/image/top.png',
            topfullPic:'/global/static/image/topfull.png'
        }
    },
    beforeMount(){
        this.userMsg = JSON.parse(window.localStorage.getItem('useMsg'));
        this.info = this.infoPic
        this.email = this.emailPic
        this.share = this.sharePic
        this.top = this.topPic
    },
    mounted () {
        this.showMessageNotifyBox = true
    },
    methods:{
        toTop(){
            let scrollToptimer = setInterval(function () {
                var top = document.body.scrollTop || document.getElementById('mainBox').scrollTop;
                var speed = top / 4;
                if (document.body.scrollTop!=0) {
                    document.body.scrollTop -= speed;
                }else {
                    document.getElementById('mainBox').scrollTop -= speed;
                }
                if (top == 0) {
                    clearInterval(scrollToptimer);
                }
            }, 30); 
        },
        handleClose(){
            this.showMessageNotify = false;
        },
        sendTheMessageNotify(){
            let postData = {
                content:this.theMessageNotify,
                name:this.userMsg.name?this.userMsg.name:'',
                qq:this.theContentQQ,
            };
            let _this = this;
            $.ajax({
                type: "POST",
                url: "/api/advice/add",
                data: postData,
                dataType: "json",
                success: function(data){
                    var warningMsg = {
                        isWarning:true,
                        showWaringBtn:false,
                        warningMsg:{
                        'image':'/global/static/image/success.png',
                        'content':'<div>'+'感谢你的意见！'+'</div>',
                        }
                    }
                    window.showWarning(warningMsg);
                    _this.theMessageNotify='';
                    _this.theContentQQ='';
                    _this.showMessageNotify = false;
                }
            });
        }
    }
})
new Vue({
    el: '#loginBox',
    data: function() {
        return {
            showWxlogin:false,
            userMoblie:'',
            pass:'',

            userName:'',
            sex:'',
            profession:'',
            province:'',
            city:'',

            cityList:[],
            provinceList:[],
            options: [{
                value: '男',
                label: '男'
            }, {
                value: '女',
                label: '女'
            }],

            widthSize:'45%',
            holeToGetCode:'0秒',
            holeToGetCodeBase:0,
            isGetCode:false,
            showTheMsgCompleteBox : false,

            intervalid1 :''
        }
    },
    beforeMount(){
        var userAgentInfo = navigator.userAgent;
        var Agents = ["Android", "iPhone",
            "SymbianOS", "Windows Phone",
            "iPad", "iPod"
        ];
        var flag = true;
        for (var v = 0; v < Agents.length; v++) {
            if (userAgentInfo.indexOf(Agents[v]) > 0) {
            flag = false;
            break;
            }
        }
    
        if (!flag) {
        this.widthSize = "80%"
        } else {
        this.widthSize = "45%"
        }
        let _this = this;
        $.ajax({
            url: "/province/list",
            type: "GET",
            dataType: "json", //指定服务器返回的数据类型
            success: function (data) {
                _this.provinceList = data.info;
            }
        });
    },
    beforeDestroy(){
        this.showWxlogin = false;
    },
    watch:{
        showWxlogin(){
            let _this = this;
            if(this.showWxlogin){
                _this.intervalid1 = setInterval(() => {
                    if(_this.getUrlKey('code')){
                        $.ajax({
                            type: "GET",
                            url: "/wxauth?code="+_this.getUrlKey('code'),
                            dataType: "json",
                            success: function(data){
                                let userMsgInfo = data.info.userinfo;
                                userMsgInfo['token']= data.info.token;
                                let userMsgInfodata = {
                                    isLogin:true,
                                    userMsg:userMsgInfo
                                }
                                window.localStorage.setItem('isLogin', userMsgInfodata.isLogin);  
                                window.localStorage.setItem('token', userMsgInfo['token']);
                                window.localStorage.setItem('useMsg', JSON.stringify(userMsgInfodata.userMsg));
                                window.location.href = "/";
                                clearInterval(_this.intervalid1)
                            }
                        });
                  }
                }, 50)
            }else{
                clearInterval(this.intervalid1)
            }
        },
        province(){
            let provinceid = '';
            let _this = this;
            this.provinceList.find((item)=>{
                if(item.name == _this.province){
                    provinceid = item.id;
                };
            });
            _this.cityList = [];
            $.ajax({
                type: "GET",
                url: "/city/list",
                data: {province:provinceid},
                dataType: "json",
                success: function(data){
                    _this.cityList = data.info;
                }
            });
        }
    },
    methods:{
        closeTheloginBox(){
            this.showWxlogin = false;
        },
        getUrlKey: function (name) {
            return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.href) || [, ""])[1].replace(/\+/g, '%20')) || null
        },
        login(){
            let postData = {
                mobile:this.userMoblie,
                code:this.pass,
            };
            let _this = this;
            $.ajax({
                type: "POST",
                url: "/auth",
                data: postData,
                dataType: "json",
                success: function(data){
                    if(data.err === 0) {
                        let userMsgInfo = data.info.userinfo;
                        userMsgInfo['token']= data.info.token;
                        let userMsgInfodata = {
                            isLogin:true,
                            userMsg:userMsgInfo
                        }
                        window.localStorage.setItem('isLogin', userMsgInfodata.isLogin);
                        window.localStorage.setItem('token', userMsgInfo['token']);
                        window.localStorage.setItem('useMsg', JSON.stringify(userMsgInfodata.userMsg));
                        window.location.href = "/";
                    } else {

                    }
                }
            });
            BaseThis.closeLogin();
        },
        getCode(){
            if(this.checkMoblie(this.userMoblie)){
                this.holeToGetCodeBase = 60;
                this.holeToGetCode = this.holeToGetCodeBase+"秒";
                var auth_timetimer =  setInterval(()=>{
                        this.holeToGetCodeBase--;
                        this.holeToGetCode = this.holeToGetCodeBase+"秒";
                        if(this.holeToGetCodeBase<=0){
                            this.sendAuthCode = true;
                            clearInterval(auth_timetimer);
                        }
                }, 1000);
                var functionBase = this;
                let postData = {
                    mobile:this.userMoblie
                };
                $.ajax({
                    type: "POST",
                    url: "/sms/send",
                    data: postData,
                    dataType: "json",
                    success: function(data){
                        functionBase.isGetCode = true;
                    },
                    error:function(){
                        functionBase.isGetCode = false;
                    }
                });
            }
        },
        checkMoblie(MoblieNum){
            var myreg = /^1[123456789]\d{9}$/;
            if(!myreg.test(MoblieNum))
            {
                return false;
            }else{
                return true;
            }
        },
        msgcomplete(){
            let _this = this;
            let postData = {
                token:window.localStorage.getItem("token"),
                name:_this.userName,
                sex: _this.sex,
                work: _this.profession,
                province: _this.province,
                city: _this.city,
            };
            $.post("/update/users",postData,function(result){

            });
        }
    }
})

new Vue({
    el: '#warning',
    data: function() {
        return {
            isWarning:false,
            showWaringBtn:false,
            widthSize:"30%",
            warningMsg:{
                'image':'/global/static/image/success.png',
                'content':'',
            }
        }
    },
    beforeMount(){
        window.showWarning = this.showWarning;
    },
    watch:{
        isWarning(){
            let _this = this;
            if(this.isWarning){
                setTimeout(() => {
                    _this.isWarning = false;
                }, 1500)
            }
        }
    },
    methods:{
        showWarning(data){
            this.isWarning = data.isWarning;
            this.warningMsg = data.warningMsg;
        }
    }
})

new Vue({
    el: '#phoneBind',
    data: function() {
        return {
            userMsg:[],
            showMobileBind:false,
            toMobileBind:false,
            theMobileBind:'',
            theMobileBindCode:'',
            canMobileBind:false,
            errorHtml:'',
            errorHtmlGetCode:'',
            codeMsg:'获取验证码',
            codeMsgCount:0,
            clock:''
        }
    },
    watch: {
        codeMsgCount(){
            let _this = this
            if(this.codeMsgCount == 60){
                clearInterval(_this.clock)
                _this.clock = window.setInterval(() => {
                    _this.codeMsgCount--
                    _this.codeMsg = '已发送验证码（'+_this.codeMsgCount+'）'
                },1000)
            }else if(this.codeMsgCount == 0){
                clearInterval(_this.clock)
                _this.codeMsg = '获取验证码'
            }else if(this.codeMsgCount < 0){
                clearInterval(_this.clock)
                _this.codeMsg = '获取验证码'
            }
        }
    },
    beforeMount() {
        let _this = this;
        this.isLogin =  window.localStorage.getItem('isLogin')?window.localStorage.getItem('isLogin'):false;
        if(this.isLogin){
            _this.userMsg = JSON.parse(window.localStorage.getItem('useMsg'));
        }
        window.showPhoneBind = this.PhoneBind;
    },
    methods:{
        PhoneBind(){
            this.showMobileBind=true;
        },
        checkTheMobileBind(){
            if(!(/^1[123456789]\d{9}$/.test(this.theMobileBind))){ 
                this.$message({
                    showClose: true,
                    message: '请输入正确的手机号',
                    type: 'warning'
                });
                this.canMobileBind = false;
            }
        },
        getCode(){
            if(!(/^1[123456789]\d{9}$/.test(this.theMobileBind))){ 
                this.$message({
                    showClose: true,
                    message: '请输入正确的手机号',
                    type: 'warning'
                });
                this.canMobileBind = false;
                return false;
            }
            this.codeMsgCount = 60
            this.codeMsg = '已发送验证码（'+this.codeMsgCount+'）'
            let postData ={
                mobile:this.theMobileBind,
                type:1
            };
            let _this = this;
            $.ajax({
                type: "POST",
                url: "/sms/send",
                data: postData,
                dataType: "json",
                success: function(data){
                    if(data.err == 0){
                        _this.$message({
                            showClose: true,
                            message: '验证码已发送',
                            type: 'success'
                        });
                        _this.canMobileBind = true;
                    }else{
                        _this.errorHtml = data.msg;
                        _this.codeMsgCount = 0
                        _this.codeMsg = '获取验证码'
                        setTimeout(() => {
                            _this.errorHtml = '';
                        }, 2000);
                        _this.canMobileBind = false;
                    }
                }
            });
        },
        MobileBind(){
            if(!this.theMobileBindCode){
                this.$message({
                    showClose: true,
                    message: '请输入验证码',
                    type: 'warning'
                });
                return false;
            }
            let postData ={
                token:this.userMsg.token,
                mobile:this.theMobileBind,
                code:this.theMobileBindCode,
            };
            let _this = this;
            $.ajax({
                type: "POST",
                url: "/api/bind/mobile",
                data: postData,
                dataType: "json",
                success: function(data){
                    if(data.err == 0){
                        _this.toMobileBind=false;
                        _this.showMobileBind=false;
                        _this.userMsg.mobile = _this.theMobileBind;
                        window.localStorage.setItem('useMsg', JSON.stringify(_this.userMsg));
                    }else{
                        _this.errorHtmlGetCode = data.msg;
                        setTimeout(() => {
                            _this.errorHtmlGetCode = '';
                        }, 2000);
                        _this.canMobileBind = false;
                    }
                }
            });
        }
    }
})